/*
    CIT 281 Project 1
    Name: Reiya Bhullor
*/

const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
console.log(`Today is ${daysOfWeek[new Date().getDay()]}`);
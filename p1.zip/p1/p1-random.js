/*
CIT 281 Project 1
Name: Reiya Bhullor
*/

// Returns a random lowercase letter from the English alphabet
function getRandomLetter() {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz';
    const randomIndex = Math.floor(Math.random() * alphabet.length);
    return alphabet[randomIndex];
  }
  
  // Returns a string of random lowercase letters between 5 - 25 characters in length
  function getRandomString() {
    const minLength = 5;
    const maxLength = 26;
    const stringLength = getRandomInteger(minLength, maxLength);
    let randomString = '';
    for (let i = 0; i < stringLength; i++) {
      randomString += getRandomLetter();
    }
    return randomString;
  }
  
  // Returns a random number between min (inclusive) and max (exclusive)
  function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
  }
  
  // Output a random string to the console
  console.log(getRandomString());